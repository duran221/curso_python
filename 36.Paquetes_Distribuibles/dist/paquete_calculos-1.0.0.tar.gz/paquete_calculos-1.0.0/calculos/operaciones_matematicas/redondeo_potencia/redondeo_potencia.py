
#Este modulo contiene las operaciones redondeo y potencia que seran usadas por un archivo externo:


def redondeo(num1):
    print(f"El resultado de la operacion es: {round(num1)}")



def potencia(num1,num2):
    print(f"El resultado de la operacion es: {num1**num2}")